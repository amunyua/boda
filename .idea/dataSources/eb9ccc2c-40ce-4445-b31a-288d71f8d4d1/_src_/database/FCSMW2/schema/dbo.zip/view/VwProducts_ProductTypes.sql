CREATE VIEW [dbo].[VwProducts_ProductTypes]
AS
SELECT        dbo.Products.Product_id, dbo.Products.Product_Name, dbo.Products.Product_Description, dbo.Products.Product_Type, dbo.Products.Product_Price, dbo.Products.Product_currency, dbo.Products.Product_IsActive, 
                         dbo.Products.Product_IsDeleted, dbo.Products.Product_DateCreated, dbo.ProductTypes.ProductType_id, dbo.ProductTypes.ProductType_Name, dbo.ProductTypes.ProductType_Description, 
                         dbo.ProductTypes.ProductType_IsActive, dbo.ProductTypes.ProductType_IsDeleted, dbo.ProductTypes.ProductType_DateCreated, dbo.Products.IsAddApproved, dbo.Products.IsDelApproved, 
                         dbo.Products.IsEditApproved, dbo.Products.IsDeletedFlag, dbo.TaxCategory.CatName
FROM            dbo.Products INNER JOIN
                         dbo.ProductTypes ON dbo.Products.Product_Type = dbo.ProductTypes.ProductType_id LEFT OUTER JOIN
                         dbo.TaxCategory ON dbo.Products.TaxCategoryID = dbo.TaxCategory.CatID


