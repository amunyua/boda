CREATE VIEW [dbo].[VwChannelGadgets]
AS
SELECT     dbo.Channels.Channel_id, dbo.Gadgets.Gadget_id, dbo.Gadgets.Gadget_Name, dbo.Channels.Channel_Name, dbo.Lnk_Gadgets_Channels.Lnk_Gadget_IsActive, 
                      dbo.Lnk_Gadgets_Channels.Lnk_Gadget_IsDeleted, dbo.Lnk_Gadgets_Channels.Lnk_Gadget_DateCreated, 
                      dbo.Lnk_Gadgets_Channels.Lnk_Gadgets_Channels_id
FROM         dbo.Channels INNER JOIN
                      dbo.Lnk_Gadgets_Channels ON dbo.Channels.Channel_id = dbo.Lnk_Gadgets_Channels.Channel_id INNER JOIN
                      dbo.Gadgets ON dbo.Lnk_Gadgets_Channels.Gadget_id = dbo.Gadgets.Gadget_id


