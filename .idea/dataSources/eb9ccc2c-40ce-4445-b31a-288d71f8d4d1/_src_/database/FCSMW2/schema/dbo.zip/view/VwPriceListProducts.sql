CREATE VIEW [dbo].[VwPriceListProducts]
AS
SELECT     dbo.Lnk_PriceList_Product.Product_id, dbo.Lnk_PriceList_Product.Price_List_id, dbo.Lnk_PriceList_Product.id, dbo.Lnk_PriceList_Product.Product_Price, 
                      dbo.Lnk_PriceList_Product.IsActive, dbo.Lnk_PriceList_Product.IsDeleted, dbo.Lnk_PriceList_Product.DateCreated, dbo.Products.Product_Name, 
                      dbo.Products.Product_Description, dbo.Products.Product_Price AS BuyingPrice, dbo.Products.Product_currency, dbo.Products.Product_Type
FROM         dbo.Lnk_PriceList_Product INNER JOIN
                      dbo.Products ON dbo.Lnk_PriceList_Product.Product_id = dbo.Products.Product_id


