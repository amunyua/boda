



CREATE VIEW [dbo].[VwCreditLimit]
AS
SELECT       RTRIM(LTRIM(ISNULL(dbo.Customers.Customer_FirstName, '') + ' ' + ISNULL(dbo.Customers.Customer_MiddleName, '') + ' ' + ISNULL(dbo.Customers.Customer_LastName, '') + ISNULL(dbo.Customers.CompanyName,''))) AS Customer_Name, 
dbo.Customers.IsActive AS IsActiveCustomer, dbo.Customers.IsDeleted AS IsDeletedCustomer,
                         dbo.PostpaidCustCreditLimits.Credit_id, dbo.PostpaidCustCreditLimits.CreditLimit, dbo.PostpaidCustCreditLimits.CreditLimit_Expiration, dbo.PostpaidCustCreditLimits.DateCreated, 
						 dbo.PostpaidCustCreditLimits.BankGuarantee,
                         dbo.PostpaidCustCreditLimits.IsActive, dbo.Customer_Account.CreditType, dbo.Customer_Account.Customer_id, dbo.PostpaidCustCreditLimits.Cust_id, dbo.Customers.Customer_id AS Expr1, 
                         dbo.Customer_Account.AccountNumber, dbo.Customers.CustomerDesignation, dbo.Customers.CompanyName
FROM            dbo.Customers INNER JOIN
                         dbo.Customer_Account ON dbo.Customers.Customer_id = dbo.Customer_Account.Customer_id LEFT OUTER JOIN
                         dbo.PostpaidCustCreditLimits ON dbo.Customer_Account.Customer_id = dbo.PostpaidCustCreditLimits.Cust_id
WHERE        (dbo.Customer_Account.CreditType = 1)





