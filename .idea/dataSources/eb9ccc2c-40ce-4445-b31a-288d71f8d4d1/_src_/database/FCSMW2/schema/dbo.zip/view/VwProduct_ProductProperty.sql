CREATE VIEW [dbo].[VwProduct_ProductProperty]
AS
SELECT     dbo.ProductProperties.ProductProperty_id, dbo.ProductProperties.ProductProperty_Name, dbo.ProductProperties.ProductProperty_Description, 
                      dbo.ProductProperties.ProductProperty_DateCreated, dbo.ProductProperties.ProductProperty_IsActive, dbo.ProductProperties.ProductProperty_IsDeleted, 
                      dbo.ProductProperties.IsAddApproved, dbo.ProductProperties.IsDelApproved, dbo.ProductProperties.IsEditApproved, dbo.ProductProperties.IsDeletedFlag, 
                      dbo.ProductProperties.IsbeingDeleted, dbo.ProductProperties.IsbeingEdited, dbo.ProductProperties.IsbeingAdded, 
                      dbo.Lnk_Products_Properties.Lnk_Products_Properties_id, dbo.Lnk_Products_Properties.Product_id, dbo.Lnk_Products_Properties.Product_Property_id, 
                      dbo.Lnk_Products_Properties.Product_Property_DateCreated, dbo.Lnk_Products_Properties.IsActive, dbo.Lnk_Products_Properties.IsDeleted
FROM         dbo.Lnk_Products_Properties INNER JOIN
                      dbo.ProductProperties ON dbo.Lnk_Products_Properties.Product_Property_id = dbo.ProductProperties.ProductProperty_id


