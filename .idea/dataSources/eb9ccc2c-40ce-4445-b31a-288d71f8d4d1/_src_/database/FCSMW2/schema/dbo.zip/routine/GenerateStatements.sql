



-- =============================================
-- Author:		Name
-- Create date: 
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[GenerateStatements] 
	-- Add the parameters for the stored procedure here
	@id bigint = 0, 
	@startdate date = NULL,
	@enddate date = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @SDate DATETIME
DECLARE @EDate DATETIME

SET @SDate = ISNULL(@startdate, GETDATE())
SET @EDate = ISNULL(@enddate, GETDATE())
    -- Insert statements for procedure here
	SELECT
        RTRIM(LTRIM(ISNULL(Customer_FirstName, '') + ' ' + ISNULL(Customer_MiddleName, '') + ' ' + ISNULL(Customer_LastName, '') + ISNULL(CompanyName, ''))) AS 'Customer',
        C.Customer_id,
		C.Customer_Email,
		CompanyPostalAddress,
        CompanyPostalCode,
        CompanyCountry,
        Customer_Phone AS Phone,    
        Mask AS Card,
	AccountNumber AS 'Account',  
        Transaction_ActualDate AS 'Date',
	Transaction_Code AS 'Transaction Code',
	Reference,
	Channel_Name AS 'Outlet',
	Product_Name AS 'Product',
	Price AS 'Unit Price',
	Units AS 'Quantity',
        TL.Discount AS 'Discount',
	Price*Units AS 'Sales_Amt',
	VehicleRegNo

FROM Customers C 
    LEFT JOIN Customer_Account CA ON C.Customer_id = CA.Customer_id
    LEFT JOIN Tickets T ON CA.AccountNumber = T.Ticket_CustomerAccountNumber
    LEFT JOIN Ticket_Lines TL ON T.Ticket_id = TL.Ticket_id
    LEFT JOIN Payments PY ON T.Ticket_id = PY.Ticket_id
    LEFT JOIN Finance_Transaction FT ON T.Transaction_id = FT.Finance_Transaction_id
    LEFT JOIN Channels CH ON T.Channel_id = CH.Channel_id
    LEFT JOIN Products P ON TL.Product_id = P.Product_id 
	LEFT JOIN Customer_Vehicle V ON V.Customer_Id = CA.Customer_id
WHERE
    C.Customer_id = @id AND
    PY.PaymentMode_id = 4 AND	
    CA.CreditType = 1 AND
    Transaction_ActualDate BETWEEN @SDate AND @EDate

ORDER BY Transaction_ActualDate
END






