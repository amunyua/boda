CREATE VIEW [dbo].[VwActivity_ActivityType]
AS
SELECT     dbo.ActivityType.ActivityType_id AS Expr1, dbo.ActivityType.ActivityType_Name, dbo.ActivityType.ActivityType_Description, dbo.ActivityType.ActivityType_IsActive, 
                      dbo.ActivityType.ActivityType_IsDeleted, dbo.ActivityType.ActivityType_DateCreated, dbo.Activity.Activity_Name, dbo.Activity.Activity_Description, 
                      dbo.Activity.Activity_IsActive, dbo.Activity.Activity_IsDeleted, dbo.Activity.Activity_DateCreated, dbo.Activity.Activity_id
FROM         dbo.Activity INNER JOIN
                      dbo.ActivityType ON dbo.Activity.ActivityType_id = dbo.ActivityType.ActivityType_id


