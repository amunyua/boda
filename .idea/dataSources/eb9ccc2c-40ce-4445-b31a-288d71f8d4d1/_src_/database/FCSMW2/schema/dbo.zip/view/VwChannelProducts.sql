CREATE VIEW [dbo].[VwChannelProducts]
AS
SELECT        dbo.Channels.Channel_Name, dbo.Products.Product_Name, dbo.Lnk_Products_Channels.Product_Price, dbo.Lnk_Products_Channels.Product_currency, 
                         dbo.Lnk_Products_Channels.Product_IsActive, dbo.Lnk_Products_Channels.Product_IsDeleted, dbo.Lnk_Products_Channels.Product_DateCreated, 
                         dbo.Lnk_Products_Channels.Lnk_Products_Channels_id, dbo.Lnk_Products_Channels.Product_id, dbo.Lnk_Products_Channels.Channel_id, 
                         dbo.Lnk_Products_Channels.PriceSchedule_Id, dbo.Lnk_Products_Channels.Scheduled_Price, dbo.Lnk_Products_Channels.Price_List_id, 
                         dbo.Products.Product_Type, dbo.Products.Product_Description
FROM            dbo.Channels INNER JOIN
                         dbo.Lnk_Products_Channels ON dbo.Channels.Channel_id = dbo.Lnk_Products_Channels.Channel_id INNER JOIN
                         dbo.Products ON dbo.Lnk_Products_Channels.Product_id = dbo.Products.Product_id


