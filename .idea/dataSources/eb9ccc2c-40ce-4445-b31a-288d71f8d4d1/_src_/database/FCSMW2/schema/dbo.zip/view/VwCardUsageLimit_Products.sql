CREATE VIEW [dbo].[VwCardUsageLimit_Products]
AS
SELECT     dbo.Products.Product_Name, dbo.CardUsageLimit.Card_UsageLimit_id, dbo.CardUsageLimit.Card_UsageLimit_Card_id, 
                      dbo.CardUsageLimit.Card_UsageLimit_Product_id, dbo.CardUsageLimit.Card_UsageLimit_Value, dbo.CardUsageLimit.Card_UsageLimit_DateCreated, 
                      dbo.CardUsageLimit.Card_UsageLimit_Type, dbo.CardUsageLimit.Card_UsageLimit_IsOverall, dbo.CardUsageLimit.Card_UsageLimit_IsActive, 
                      dbo.CardUsageLimit.Card_UsageLimit_IsDeleted, dbo.TimeDuration.Value, dbo.TimeDuration.TimeDuration_id
FROM         dbo.CardUsageLimit LEFT OUTER JOIN
                      dbo.Products ON dbo.CardUsageLimit.Card_UsageLimit_Product_id = dbo.Products.Product_id INNER JOIN
                      dbo.TimeDuration ON dbo.CardUsageLimit.Card_UsageLimit_Type = dbo.TimeDuration.TimeDuration_id


