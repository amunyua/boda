CREATE VIEW [dbo].[VwDiscountProducts]
AS
SELECT     dbo.Lnk_Discount_Product.Product_id, dbo.Lnk_Discount_Product.Channel_id, dbo.Lnk_Discount_Product.Discount_List_id, 
                      dbo.Lnk_Discount_Product.Discount_Value, dbo.Lnk_Discount_Product.Discount_Currency, dbo.Lnk_Discount_Product.Discount_Type, dbo.Products.Product_Name, 
                      dbo.Products.Product_Description, dbo.Products.Product_Type, dbo.Products.Product_Price, dbo.Products.Product_currency, dbo.Lnk_Discount_Product.id, 
                      dbo.Channels.Channel_Name
FROM         dbo.Lnk_Discount_Product INNER JOIN
                      dbo.Products ON dbo.Lnk_Discount_Product.Product_id = dbo.Products.Product_id INNER JOIN
                      dbo.Channels ON dbo.Lnk_Discount_Product.Channel_id = dbo.Channels.Channel_id


