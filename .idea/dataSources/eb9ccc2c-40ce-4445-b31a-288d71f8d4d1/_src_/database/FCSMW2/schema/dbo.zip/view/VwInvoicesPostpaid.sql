
CREATE VIEW [dbo].[VwInvoicesPostpaid]
AS
SELECT        dbo.InvoicesPostpaidMaster.Invoice_Id, dbo.InvoicesPostpaidMaster.Customer_Id, dbo.InvoicesPostpaidMaster.Customer, dbo.InvoicesPostpaidMaster.CompanyPostalAddress, 
                         dbo.InvoicesPostpaidMaster.CompanyPostalCode, dbo.InvoicesPostpaidMaster.CompanyCountry, dbo.InvoicesPostpaidMaster.Phone, dbo.InvoicesPostpaidMaster.Email, dbo.InvoicesPostpaidMaster.FromDate, 
                         dbo.InvoicesPostpaidMaster.ToDate, dbo.InvoicesPostpaidMaster.BillingCycle, dbo.InvoicesPostpaidMaster.IsMailed, dbo.InvoicesPostpaidMaster.DateMailed, dbo.InvoicesPostpaidMaster.DateCreated, 
                         dbo.InvoicesPostpaidMaster.ModifiedBy, dbo.InvoicesPostpaid.Mask, dbo.InvoicesPostpaid.Account, dbo.InvoicesPostpaid.Date, dbo.InvoicesPostpaid.Transaction_Code, dbo.InvoicesPostpaid.ChannelName, 
                         dbo.InvoicesPostpaid.Product, dbo.InvoicesPostpaid.Price, dbo.InvoicesPostpaid.Units, dbo.InvoicesPostpaid.Discount, dbo.InvoicesPostpaid.Sales_Amt, 
                         dbo.InvoicesPostpaid.DateCreated AS InvoiceDateCreated
FROM            dbo.InvoicesPostpaid INNER JOIN
                         dbo.InvoicesPostpaidMaster ON dbo.InvoicesPostpaid.InvoiceId = dbo.InvoicesPostpaidMaster.Invoice_Id


