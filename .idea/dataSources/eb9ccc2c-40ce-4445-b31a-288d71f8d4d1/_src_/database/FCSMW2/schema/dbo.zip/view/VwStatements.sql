

CREATE VIEW [dbo].[VwStatements]
AS
SELECT        dbo.StatementMaster.Statement_Id, dbo.StatementMaster.Customer_Id, dbo.StatementMaster.Customer, dbo.StatementMaster.CompanyPostalAddress, dbo.StatementMaster.CompanyPostalCode, 
                         dbo.StatementMaster.CompanyCountry, dbo.StatementMaster.Phone, dbo.StatementMaster.Email, dbo.StatementMaster.StartDate, dbo.StatementMaster.EndDate, dbo.StatementMaster.BillingCycle, 
                         dbo.StatementMaster.Balance, dbo.StatementMaster.TotalDue,
						 dbo.StatementMaster.IsMailed, dbo.StatementMaster.DateMailed, dbo.StatementMaster.DateCreated, dbo.Statements.Id, dbo.Statements.StatementId, dbo.Statements.Mask, dbo.Statements.Account, 
                         dbo.Statements.Date, dbo.Statements.Transaction_Code, dbo.Statements.Reference, dbo.Statements.ChannelName, dbo.Statements.Product, dbo.Statements.Price, dbo.Statements.Units, dbo.Statements.Discount, 
                         dbo.Statements.Sales_Amt
FROM            dbo.StatementMaster INNER JOIN
                         dbo.Statements ON dbo.StatementMaster.Statement_Id = dbo.Statements.StatementId



