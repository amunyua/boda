--RTRIM(LTRIM(ISNULL(dbo.Customers.Customer_FirstName, '') + ' ' + ISNULL(dbo.Customers.Customer_MiddleName, '') + ' ' + ISNULL(dbo.Customers.Customer_LastName, '') + ISNULL(dbo.Customers.CompanyName, ''))) AS Customer_FirstName,

CREATE VIEW [dbo].[VwCardsCustomers]
AS
SELECT     dbo.Customers.Customer_id, RTRIM(LTRIM(ISNULL(dbo.Customers.Customer_FirstName, '') + ' ' + ISNULL(dbo.Customers.Customer_MiddleName, '') + ' ' + ISNULL(dbo.Customers.Customer_LastName, '') + ISNULL(dbo.Customers.CompanyName, ''))) AS Customer_FirstName, dbo.Customers.Customer_OtherName, dbo.Customers.Customer_DoB, 
                      dbo.Customers.Customer_Gender, dbo.Customers.Customer_Email, dbo.Customers.Customer_Password, dbo.Customers.Customer_Phone, 
                      dbo.Customers.Customer_Country, dbo.Customers.Customer_Role, dbo.Customers.IsActive, dbo.Customers.IsDeleted, dbo.Customers.IsVerificationMailSent, 
                      dbo.Customers.IsVerified, dbo.Customers.VerificationMailDate, dbo.Customers.PasswordResetLnkDate, dbo.Customers.DateCreated, dbo.Cards.Card_id, 
                      dbo.Cards.Card_UID, dbo.Cards.Card_SNO, dbo.Cards.Card_Type, dbo.Cards.Card_Owner, dbo.Cards.Card_Owner_Employee, dbo.Cards.Card_Balance, 
                      dbo.Cards.Card_Points_Balance, dbo.Cards.Card_OverDraftValue, dbo.Cards.Card_PrepaidAmt, dbo.Cards.Card_IsAssigned, dbo.Cards.Card_IsActive, 
                      dbo.Cards.Card_IsDeleted, dbo.Cards.Card_DateAssigned, dbo.Cards.Card_UploadDate, dbo.Cards.Card_UpdateDate, dbo.Cards.Card_PIN, 
                      dbo.Cards.Card_IsAssignedtoEmp
FROM         dbo.Cards LEFT OUTER JOIN
                      dbo.Customers ON dbo.Cards.Card_Owner = dbo.Customers.Customer_id




