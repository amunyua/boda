




CREATE VIEW [dbo].[VwCustomerAccount]
AS
SELECT     dbo.Customer_Account.AccountNumber, dbo.Customer_Account.Customer_id, dbo.Customer_Account.AccountType_id, dbo.Customer_Account.Mask_Type, 
                      dbo.Customer_Account.Mask, dbo.Customer_Account.CreditType, dbo.Customer_Account.IsDeleted, dbo.Customer_Account.DateCreated, 
                      dbo.Customer_Account.Balance, RTRIM(LTRIM(ISNULL(dbo.Customers.Customer_FirstName, '') + ' ' + ISNULL(dbo.Customers.Customer_MiddleName, '') + ' ' + ISNULL(dbo.Customers.Customer_LastName, '') + ISNULL(dbo.Customers.CompanyName, ''))) AS Customer_Name, dbo.Customers.CustomerDesignation, dbo.Customers.IsActive AS IsActiveCustomer, dbo.Customers.IsDeleted AS IsDeletedCustomer, dbo.AccountType.id, dbo.AccountType.AccType, dbo.Customer_Account.IsActive
FROM         dbo.Customer_Account INNER JOIN
                      dbo.Customers ON dbo.Customer_Account.Customer_id = dbo.Customers.Customer_id INNER JOIN
                      dbo.AccountType ON dbo.Customer_Account.AccountType_id = dbo.AccountType.id







