CREATE VIEW [dbo].[VwCustomers]
AS
SELECT        Customer_id, RTRIM(LTRIM(ISNULL(Customer_FirstName, '') + ' ' + ISNULL(Customer_MiddleName, '') + ' ' + ISNULL(Customer_LastName, '') + ISNULL(CompanyName, ''))) AS Customer_Name, 
                         Customer_OtherName, Customer_DoB, Customer_Gender, Customer_Email, Customer_Password, Customer_Phone, Customer_Country, Customer_Role, IsActive, IsDeleted, IsVerificationMailSent, IsVerified, 
                         VerificationMailDate, PasswordResetLnkDate, DateCreated, IsBlocked, IsAddApproved, IsDelApproved, IsEditApproved, TotalEmp, ReportingPassword, Payment_Term_id, AutoRedistributeFunds, Price_List_id, 
                         Discount_List_id, CustomerDesignation, ModifiedBy, CustomerTaxCategoryID, Customer_PIN, Customer_IDNumber, Customer_PostalAddress, Customer_PostalCode, Customer_Mobile, 
                         Customer_ContactNoHome, Customer_ContactNoOffice, Customer_Fax, NOK_FirstName, NOK_MiddleName, NOK_LastName, NOK_Email, NOK_Phone, Customer_BankName, Customer_BankBranch, 
                         Customer_AccountNumber, Customer_AccountCurrency, CompanyName, CompanyIncorporationDate, CompanyRegistrationNo, CompanyPIN, CompanyVAT, CompanyPostalAddress, CompanyPostalCode, 
                         CompanyCountry, CompanyPhysicalAddress, CompanyPhysicalPostalCode, CompanyPhysicalAddressCountry, CompanyDirectorFirstName1, CompanyDirectorMiddleName1, CompanyDirectorLastName1, 
                         CompanyDirectorEmail1, CompanyDirectorPhone1, CompanyDirectorPIN1, CompanyDirectorID1, CompanyDirectorFirstName2, CompanyDirectorMiddleName2, CompanyDirectorLastName2, 
                         CompanyDirectorEmail2, CompanyDirectorPhone2, CompanyDirectorPIN2, CompanyDirectorID2, CompanyDirectorFirstName3, CompanyDirectorMiddleName3, CompanyDirectorLastName3, 
                         CompanyDirectorEmail3, CompanyDirectorPhone3, CompanyDirectorPIN3, CompanyDirectorID3, CompanyContactPersonName1, CompanyContactPersonPosition1, CompanyContactPersonEmail1, 
                         CompanyContactPersonPhone1, CompanyContactPersonName2, CompanyContactPersonPosition2, CompanyContactPersonEmail2, CompanyContactPersonPhone2, CF1, CF2, CF3, CF4, CF5, CF6, CF7, CF8, CF9, 
                         CF10
FROM            dbo.Customers

