CREATE VIEW [dbo].[VwChannelProductSchedule]
AS
SELECT     dbo.Lnk_Products_Channels.Lnk_Products_Channels_id, dbo.Lnk_Products_Channels.Product_id, dbo.Lnk_Products_Channels.Channel_id, 
                      dbo.Lnk_Products_Channels.Product_Price, dbo.Lnk_Products_Channels.Product_currency, dbo.Lnk_Products_Channels.Product_IsActive, 
                      dbo.Lnk_Products_Channels.Product_IsDeleted, dbo.Lnk_Products_Channels.Product_DateCreated, dbo.Lnk_Products_Channels.PriceSchedule_Id, 
                      dbo.Lnk_Products_Channels.Scheduled_Price, dbo.Products.Product_Name, dbo.Channels.Channel_Name, dbo.Schedule.Schedule_Name, 
                      dbo.Schedule.Effective_Date, dbo.Schedule.Schedule_IsActive, dbo.Schedule.Schedule_IsDeleted, dbo.Schedule.Schedule_DateCreated, 
                      dbo.Lnk_Products_Channels.Price_List_id, dbo.PriceList.PriceList_Name
FROM         dbo.Lnk_Products_Channels INNER JOIN
                      dbo.Products ON dbo.Lnk_Products_Channels.Product_id = dbo.Products.Product_id INNER JOIN
                      dbo.Channels ON dbo.Lnk_Products_Channels.Channel_id = dbo.Channels.Channel_id INNER JOIN
                      dbo.Schedule ON dbo.Lnk_Products_Channels.PriceSchedule_Id = dbo.Schedule.Schedule_Id LEFT OUTER JOIN
                      dbo.PriceList ON dbo.Lnk_Products_Channels.Price_List_id = dbo.PriceList.PriceList_id


