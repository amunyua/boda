CREATE VIEW [dbo].[VwChannels_ChannelTypes]
AS
SELECT     dbo.ChannelTypes.ChannelType_id, dbo.ChannelTypes.ChannelType_Name, dbo.ChannelTypes.ChannelType_Description, dbo.ChannelTypes.ChannelType_IsActive, 
                      dbo.ChannelTypes.ChannelType_IsDeleted, dbo.ChannelTypes.ChannelType_DateCreated, dbo.Channels.Channel_id, dbo.Channels.Channel_Name, 
                      dbo.Channels.Channel_Description, dbo.Channels.Channel_Type, dbo.Channels.Channel_Country, dbo.Channels.Channel_Address, dbo.Channels.Channel_City, 
                      dbo.Channels.Channel_IsDeleted, dbo.Channels.Channel_IsActive, dbo.Channels.Channel_DateCreated, dbo.Channels.Channel_IsSelected, 
                      dbo.Channels.IsAddApproved, dbo.Channels.IsDelApproved, dbo.Channels.IsEditApproved, dbo.Channels.IsDeletedFlag
FROM         dbo.Channels INNER JOIN
                      dbo.ChannelTypes ON dbo.Channels.Channel_Type = dbo.ChannelTypes.ChannelType_id


