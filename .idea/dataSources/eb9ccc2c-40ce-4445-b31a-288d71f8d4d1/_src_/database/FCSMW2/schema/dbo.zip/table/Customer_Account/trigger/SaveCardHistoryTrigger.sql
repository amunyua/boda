-- =============================================
-- Author:		Surendra
-- Create date: 26 Nov 2016
-- Description:	Saves history of card when card mask is changed in the accounts management
-- =============================================
CREATE TRIGGER [dbo].[SaveCardHistoryTrigger] 
   ON  [dbo].[Customer_Account] 
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	INSERT INTO [dbo].[CardsHistory]
Select d.Mask
           ,i.Mask
           ,i.AccountNumber
           ,i.Customer_id
           ,i.AccountType_id
           ,i.Mask_Type
           ,i.Mask
           ,i.CreditType
           ,i.IsDeleted
           ,i.DateCreated
           ,i.Balance
           ,i.IsCollection
           ,i.Employee_id
           ,i.ModifiedBy
      FROM Inserted i
      INNER JOIN Deleted d ON i.AccountNumber = d.AccountNumber

END

