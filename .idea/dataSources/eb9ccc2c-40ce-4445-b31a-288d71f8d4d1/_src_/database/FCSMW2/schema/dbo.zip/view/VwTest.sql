CREATE VIEW [dbo].[VwTest]
AS
SELECT     dbo.PostpaidCustCreditLimits.*
FROM         dbo.PostpaidCustCreditLimits


