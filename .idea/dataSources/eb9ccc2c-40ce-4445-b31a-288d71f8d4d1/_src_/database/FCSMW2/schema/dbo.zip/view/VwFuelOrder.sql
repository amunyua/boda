

CREATE VIEW [dbo].[VwFuelOrder]
AS
SELECT        dbo.FuelOrder.FuelOrderId, dbo.FuelOrder.PaymentTermId, dbo.FuelOrder.DueDate, dbo.FuelOrder.TotalAmount, dbo.FuelOrder.Currency, dbo.FuelOrder.IsLimitByProduct, dbo.FuelOrder.Customer, dbo.FuelOrder.Address, dbo.FuelOrder.Email,
                         dbo.FuelOrder.IsValidated, dbo.FuelOrder.IsActive, dbo.FuelOrder.IsDeleted, dbo.FuelOrder.DateCreated, dbo.FuelOrder.DateUpdated, dbo.FuelOrder.ModifiedBy, dbo.FuelOrder.CreatedBy, 
                         dbo.FuelOrder.ValidatedBy, dbo.FuelOrder.CustomerId, dbo.Payment_Terms.PaymentTerm_Name, dbo.Payment_Terms.DayInFollowingMonth, dbo.Payment_Terms.DaysBeforeDue
FROM            dbo.FuelOrder INNER JOIN
                         dbo.Payment_Terms ON dbo.FuelOrder.PaymentTermId = dbo.Payment_Terms.PaymentTerm_id



