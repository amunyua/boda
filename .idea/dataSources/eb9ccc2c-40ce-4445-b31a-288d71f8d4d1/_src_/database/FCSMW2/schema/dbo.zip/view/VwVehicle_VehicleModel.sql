CREATE VIEW [dbo].[VwVehicle_VehicleModel]
AS
SELECT     dbo.Vehicle.Vehicle_Id, dbo.Vehicle.Vehicle_Make, dbo.Vehicle.VehicleIsActive, dbo.Vehicle.VehicleIsDeleted, dbo.Vehicle.VehicleDateCreated, 
                      dbo.VehicleModel.VehicleModel_Id, dbo.VehicleModel.VehicleModel_Name, dbo.VehicleModel.VehicleModelIsActive, dbo.VehicleModel.VehicleModelIsDeleted, 
                      dbo.VehicleModel.VehicleModelDateCreated, dbo.VehicleModel.VehicleId, dbo.VehicleModel.TankCapacity
FROM         dbo.Vehicle INNER JOIN
                      dbo.VehicleModel ON dbo.Vehicle.Vehicle_Id = dbo.VehicleModel.VehicleId


