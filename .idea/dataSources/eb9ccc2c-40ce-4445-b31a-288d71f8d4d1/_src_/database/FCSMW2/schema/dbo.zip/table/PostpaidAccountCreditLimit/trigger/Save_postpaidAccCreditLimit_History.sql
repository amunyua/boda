
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Save_postpaidAccCreditLimit_History] 
   ON  [dbo].[PostpaidAccountCreditLimit] 
   AFTER INSERT, UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Insert into PostpaidAccCrLimitHistory
	SELECT [id]
      ,[Credit_id]
      ,[AccountNumber]
      ,[Account_CreditLimit]
      ,[DateCreated]
      ,[IsActive]
      ,[ModifiedBy] FROM inserted

END


