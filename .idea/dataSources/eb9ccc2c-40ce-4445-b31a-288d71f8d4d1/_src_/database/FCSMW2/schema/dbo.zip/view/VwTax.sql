


CREATE VIEW [dbo].[VwTax]
AS
SELECT        dbo.Tax.TaxID, dbo.Tax.TaxName, dbo.Tax.TaxDescription,dbo.Tax.IsActive,dbo.Tax.IsDeleted,dbo.Tax.DateCreated, dbo.TaxCategory.CatName, dbo.Customer_TaxCategory.CustCatName, dbo.TaxRate.TaxRateName
FROM            dbo.TaxRate RIGHT OUTER JOIN
                         dbo.Tax ON dbo.TaxRate.TaxRateID = dbo.Tax.TaxRateID LEFT OUTER JOIN
                         dbo.Customer_TaxCategory ON dbo.Tax.CustCatID = dbo.Customer_TaxCategory.CustCatID LEFT OUTER JOIN
                         dbo.TaxCategory ON dbo.Tax.CatID = dbo.TaxCategory.CatID





