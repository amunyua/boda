
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[PostpaidCustCreditLimits_SaveHistory] 
   ON  [dbo].[PostpaidCustCreditLimits] 
   AFTER INSERT, UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	BEGIN
	--INSERT INTO [dbo].[PostpaidCrLimitsHistory]
           --([Credit_id]
           --,[Cust_id]
           --,[CreditLimit]
           --,[CreditLimit_Expiration]
           --,[DateCreated]
           --,[IsActive]
           --,[ModifiedBy]
           --,[BankGuarantee])
	--VALUES (OLD.Credit_id, 
	--OLD.Cust_id, 
	--OLD.CreditLimit,
	--OLD.CreditLimit_Expiration,
	--NULL,
	--OLD.IsActive,
	--OLD.ModifiedBy,
	--OLD.BankGuarantee)
	INSERT INTO [dbo].[PostpaidCrLimitsHistory]
	SELECT [Credit_id]
           ,[Cust_id]
           ,[CreditLimit]
           ,[CreditLimit_Expiration]
           ,getdate()
           ,[IsActive]
           ,[ModifiedBy]
           ,[BankGuarantee] FROM INSERTED
	END
END


