
CREATE VIEW [dbo].[VwCustomerEmpAccount]
AS
SELECT     dbo.Customer_Account.AccountNumber, cust.Customer_id, RTRIM(LTRIM(ISNULL(Customer_FirstName, '') + ' ' + ISNULL(Customer_MiddleName, '') + ' ' + ISNULL(Customer_LastName, '') + ISNULL(CompanyName, ''))) AS Customer_Name, 
emp.Emp_id, emp.Emp_Name, dbo.Customer_Account.IsDeleted
FROM         dbo.Employee AS emp RIGHT OUTER JOIN
                      dbo.Customer_Account ON emp.Emp_id = dbo.Customer_Account.Employee_id LEFT OUTER JOIN
                      dbo.Customers AS cust ON dbo.Customer_Account.Customer_id = cust.Customer_id



