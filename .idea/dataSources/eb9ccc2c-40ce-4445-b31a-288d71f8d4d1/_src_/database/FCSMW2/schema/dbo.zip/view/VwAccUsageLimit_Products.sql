CREATE VIEW [dbo].[VwAccUsageLimit_Products]
AS
SELECT     dbo.Customer_AccountUsageLimit.UsageLimit_Product_id, dbo.TimeDuration.TimeDuration_id, dbo.Customer_AccountUsageLimit.UsageLimit_id, 
                      dbo.Customer_AccountUsageLimit.UsageLimit_AccountNumber, dbo.Customer_AccountUsageLimit.UsageLimit_Value, 
                      dbo.Customer_AccountUsageLimit.UsageLimit_DateCreated, dbo.Customer_AccountUsageLimit.UsageLimit_Type, 
                      dbo.Customer_AccountUsageLimit.UsageLimit_IsOverall, dbo.Customer_AccountUsageLimit.UsageLimit_IsActive, 
                      dbo.Customer_AccountUsageLimit.UsageLimit_IsDeleted, dbo.Products.Product_id, dbo.Products.Product_Name, dbo.Products.Product_Description, 
                      dbo.Products.Product_Type, dbo.Products.Product_Price, dbo.Products.Product_currency, dbo.Products.Product_IsActive, dbo.Products.Product_IsDeleted, 
                      dbo.Products.Product_DateCreated, dbo.TimeDuration.Value, dbo.TimeDuration.Type
FROM         dbo.Customer_AccountUsageLimit LEFT JOIN
                      dbo.Products ON dbo.Customer_AccountUsageLimit.UsageLimit_Product_id = dbo.Products.Product_id INNER JOIN
                      dbo.TimeDuration ON dbo.Customer_AccountUsageLimit.UsageLimit_Type = dbo.TimeDuration.TimeDuration_id


