CREATE VIEW `all_address_type` AS
  SELECT
    `a`.`masterfile_id`     AS `masterfile_id`,
    `a`.`county`            AS `county`,
    `a`.`city`              AS `city`,
    `a`.`email`             AS `email`,
    `a`.`tel_no`            AS `tel_no`,
    `a`.`phone_no`          AS `phone_no`,
    `a`.`postal_address`    AS `postal_address`,
    `a`.`physical_address`  AS `physical_address`,
    `a`.`postal_code`       AS `postal_code`,
    `c`.`contact_type_name` AS `contact_type_name`,
    `c`.`contact_type_code` AS `contact_type_code`
  FROM (`ride`.`contact_types` `c` LEFT JOIN `ride`.`addresses` `a` ON ((`c`.`id` = `a`.`contact_type_id`)))