CREATE VIEW `all_users` AS
  SELECT
    `u`.`id`        AS `id`,
    `u`.`name`      AS `name`,
    `r`.`role_name` AS `role_name`,
    `u`.`status`    AS `status`,
    `ru`.`user_id`  AS `user_id`
  FROM ((`ride`.`users` `u` LEFT JOIN `ride`.`role_user` `ru` ON ((`ru`.`user_id` = `u`.`id`))) LEFT JOIN
    `ride`.`roles` `r` ON ((`r`.`id` = `ru`.`role_id`)))