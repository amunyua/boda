CREATE VIEW `bill_data` AS
  SELECT
    `cb`.`id`                                                          AS `id`,
    `cb`.`client_account_id`                                           AS `client_account_id`,
    `cb`.`bill_amount`                                                 AS `bill_amount`,
    `cb`.`masterfile_id`                                               AS `masterfile_id`,
    `cb`.`bill_balance`                                                AS `bill_balance`,
    `cb`.`amount_paid`                                                 AS `amount_paid`,
    `cb`.`bill_status`                                                 AS `bill_status`,
    `cb`.`service_id`                                                  AS `service_id`,
    `cb`.`bill_date`                                                   AS `bill_date`,
    `cb`.`bill_due_date`                                               AS `bill_due_date`,
    `cb`.`deleted_at`                                                  AS `deleted_at`,
    `cb`.`created_at`                                                  AS `created_at`,
    `cb`.`updated_at`                                                  AS `updated_at`,
    concat(`m`.`surname`, ' ', `m`.`firstname`, ' ', `m`.`middlename`) AS `rider`,
    `sc`.`service_name`                                                AS `service_name`
  FROM
    ((`ride`.`customer_bills` `cb` LEFT JOIN `ride`.`masterfiles` `m` ON ((`cb`.`masterfile_id` = `m`.`id`))) LEFT JOIN
      `ride`.`services` `sc` ON ((`cb`.`service_id` = `sc`.`id`)))