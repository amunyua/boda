CREATE VIEW `all_masterfile` AS
  SELECT
    `m`.`id`                                                           AS `id`,
    concat(`m`.`surname`, ' ', `m`.`firstname`, ' ', `m`.`middlename`) AS `full_name`,
    `m`.`id_no`                                                        AS `id_no`,
    `m`.`gender`                                                       AS `gender`,
    `m`.`b_role`                                                       AS `b_role`,
    `m`.`user_role`                                                    AS `user_role`,
    `r`.`role_name`                                                    AS `role_name`,
    `m`.`status`                                                       AS `status`,
    `m`.`registration_date`                                            AS `registration_date`,
    `ad`.`email`                                                       AS `email`,
    `ad`.`phone_no`                                                    AS `phone_no`,
    `ad`.`postal_address`                                              AS `postal_address`,
    `ad`.`postal_code`                                                 AS `postal_code`,
    `ad`.`physical_address`                                            AS `physical_address`,
    `ad`.`county`                                                      AS `county`,
    `ad`.`city`                                                        AS `city`
  FROM (((`ride`.`masterfiles` `m` LEFT JOIN `ride`.`addresses` `a` ON ((`m`.`id` = `a`.`masterfile_id`))) LEFT JOIN
    `ride`.`roles` `r` ON ((`r`.`id` = `m`.`user_role`))) LEFT JOIN `ride`.`addresses` `ad`
      ON ((`ad`.`masterfile_id` = `m`.`id`)))